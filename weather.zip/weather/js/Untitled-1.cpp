#include <iostream>
#include <bits/stdc++.h>
using namespace std;
#define faster ios_base::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
int main() {
    faster
    int t=1;
    cin>>t;
    while (t--){
        long long int n,s=0,k=0,l=0,nn,v,v2,h1,h2,m1,m2,val;
        long long int arr[3];
        char c,cc;
        map<char , long long int >mp;
        string sl,sk,ss="";
        pair<long long int ,long long int>a[3];
  cin>>sl;
        for (int i = 0; i <sl.lenth ; ++i) {
 

 
 mp[sl[i]]++;
 
        }
        for (auto it = mp.begin(); it != mp.end(); ++it) {
            for(int i = 0; i <= it->second; ++i)
        cout << it->first ;
    }

 
        
        cout<<"\n";
    }
    return 0;
}