fetch(`https://api.weatherapi.com/v1/current.json?key=cdfed69ec8574896b80213434241712&q=Cairo&aqi=no`)
  .then(response => response.json()) // Parse the JSON response
  .then(data => {
    
    console.log(data); // Log the entire data object for inspection

    // Access specific data points
    const location = data.location;
    const currentWeather = data.current;
    console.log( location);
    console.log("City:", currentWeather.condition.icon);
    console.log("Region:", location.region);
    console.log("Current temperature in Celsius:", currentWeather.temp_c);
    console.log("Current temperature in Fahrenheit:", currentWeather.temp_f);
    console.log("Weather condition:", currentWeather.condition.text);
    console.log("Wind speed (mph):", currentWeather.wind_mph);
    console.log("Humidity (%):", currentWeather.humidity);
    // ... Access other data points as needed


   let v=`<div class="card-group  fst-italic">
  <div class="card bg">
    
    <div class="card-body">
      <h2 class="card-title  p-3 fs-1 ">${location.name}</h2>
      <h3 class="card-title p-2">${location.country}</h3>
      <h5 class="card-title p-2">Last updated </h5>
      <h5 class="card-title p-2">${currentWeather.last_updated}</h5>
     
    
    </div>
  </div>
  <div class="card bgc">
    
    <div class="card-body ">
     
       <h2 class="card-title p-3 fs-1"> ${currentWeather.condition.text}</h2>
<img src="https:${currentWeather.condition.icon}" class="card-img-top w-25" alt="...">

  <h1 class="card-title">${currentWeather.temp_c}</h1>
  <h3 class="card-title">feel like</h3>
   <h3 class="card-title">${currentWeather.feelslike_c}</h3>

     
    </div>
  </div>
  <div class="card bg">
  
    <div class="card-body">
      
      <h3 class="card-title p-3"><i class="fa-solid fa-wind"></i>  ${currentWeather.wind_mph} m/h</h3>

       <h3 class="card-title p-3"><i class="fa-solid fa-cloud-showers-heavy"></i>  ${currentWeather.precip_mm} mm</h3>
        <h3 class="card-title p-3"><i class="fa-solid fa-snowflake"></i> ${currentWeather.cloud} C</h3>
      <h5 class="card-title p-2">pressure : ${currentWeather.pressure_mb} mb</h5> 
       <h5 class="card-title p-2">humidity : ${currentWeather.humidity} % </h5>
       <h5 class="card-title p-2"> U.V: ${currentWeather.uv}</h5>
     
    </div>
  </div>
</div>`;
      document.getElementById("weather").innerHTML = v;

  })
  .catch(error => {
    console.error("Error fetching weather data:", error);
  });


function searchToggle(obj, evt){
    var container = $(obj).closest('.search-wrapper');
        if(!container.hasClass('active')){
            container.addClass('active');
            evt.preventDefault();
        }
        else if(container.hasClass('active') && $(obj).closest('.input-holder').length == 0){
            container.removeClass('active');
            // clear input
            container.find('.search-input').val('');
        }
}



$("#searchName").keyup(function () {
    var searchval = document.getElementById("searchName").value
    fetch(`https://api.weatherapi.com/v1/current.json?key=cdfed69ec8574896b80213434241712&q=${searchval}&aqi=no`)
    .then(response => response.json()) // Parse the JSON response
    .then(data => {
      
      console.log(data); // Log the entire data object for inspection
  
      // Access specific data points
      const location = data.location;
      const currentWeather = data.current;
      console.log( location);
      console.log("City:", currentWeather.condition.icon);
      console.log("Region:", location.region);
      console.log("Current temperature in Celsius:", currentWeather.temp_c);
      console.log("Current temperature in Fahrenheit:", currentWeather.temp_f);
      console.log("Weather condition:", currentWeather.condition.text);
      console.log("Wind speed (mph):", currentWeather.wind_mph);
      console.log("Humidity (%):", currentWeather.humidity);
      // ... Access other data points as needed
  
  
      let v=`<div class="card-group  fst-italic">
      <div class="card bg">
        
        <div class="card-body">
          <h2 class="card-title  p-3 fs-1 ">${location.name}</h2>
          <h3 class="card-title p-2">${location.country}</h3>
          <h5 class="card-title p-2">Last updated </h5>
          <h5 class="card-title p-2">${currentWeather.last_updated}</h5>
         
        
        </div>
      </div>
      <div class="card bgc">
        
        <div class="card-body ">
         
           <h2 class="card-title p-3 fs-1"> ${currentWeather.condition.text}</h2>
    <img src="https:${currentWeather.condition.icon}" class="card-img-top w-25" alt="...">
    
      <h1 class="card-title">${currentWeather.temp_c}</h1>
      <h3 class="card-title">feel like</h3>
       <h3 class="card-title">${currentWeather.feelslike_c}</h3>
    
         
        </div>
      </div>
      <div class="card bg">
      
        <div class="card-body">
          
          <h3 class="card-title p-3"><i class="fa-solid fa-wind"></i>  ${currentWeather.wind_mph} m/h</h3>
    
           <h3 class="card-title p-3"><i class="fa-solid fa-cloud-showers-heavy"></i>  ${currentWeather.precip_mm} mm</h3>
            <h3 class="card-title p-3"><i class="fa-solid fa-snowflake"></i> ${currentWeather.cloud} C</h3>
          <h5 class="card-title p-2">pressure : ${currentWeather.pressure_mb} mb</h5> 
           <h5 class="card-title p-2">humidity : ${currentWeather.humidity} % </h5>
           <h5 class="card-title p-2"> U.V: ${currentWeather.uv}</h5>
         
        </div>
      </div>
    </div>`;
          document.getElementById("weather").innerHTML = v;
  
    })
    .catch(error => {
      console.error("Error fetching weather data:", error);
    });
  
  
  })